class Senderismo {
  String? uid;
  String? titulo;
  String? distancia;
  String? desnivel;
  String? descripcion;
  String? mapa;
  List<dynamic>? imagenes;

  Senderismo({
    this.uid,
    this.titulo,
    this.distancia,
    this.desnivel,
    this.descripcion,
    this.mapa,
    this.imagenes,
  });
}
