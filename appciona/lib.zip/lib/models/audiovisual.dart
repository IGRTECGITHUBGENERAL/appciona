class Audiovisual {
  String? descripcion;
  DateTime? fechaPublicacion;
  String? imagen;
  String? link;
  String? tipo;
  String? titulo;
  String? uid;

  Audiovisual({
    this.descripcion,
    this.fechaPublicacion,
    this.imagen,
    this.link,
    this.tipo,
    this.titulo,
    this.uid,
  });
}
