class Noticia {
  String? categoria;
  String? titulo;
  DateTime? fecha;
  String? subtitulo;
  String? imagen;
  String? texto;
  String? link;

  Noticia({
    this.categoria,
    this.titulo,
    this.fecha,
    this.subtitulo,
    this.imagen,
    this.texto,
    this.link,
  });
}
