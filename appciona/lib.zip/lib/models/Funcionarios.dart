class Funcionarios {
  String? UID;
  String? Nombre;
  String? Cargo;

  Funcionarios({
    this.UID,
    this.Nombre,
    this.Cargo,


  });
}