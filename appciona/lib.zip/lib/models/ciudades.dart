class Ciudades {
  String? UID;
  String? Nombre;

  Ciudades({
    this.UID,
    this.Nombre,


  });
}