class Turismo {
  String? correo;
  String? direccion;
  String? imagen;
  String? link;
  String? telefono;
  String? tipo;
  String? titulo;

  Turismo({
    this.correo,
    this.direccion,
    this.imagen,
    this.link,
    this.telefono,
    this.tipo,
    this.titulo,
  });
}
